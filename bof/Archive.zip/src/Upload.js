import React, { useState } from 'react'
import './Upload.css'
import db from './FirebaseRDB';
import storage from './FirebaseS'
import { ref, set } from "firebase/database";
import { uploadBytes, ref as sRef } from "firebase/storage";

function Upload() {
    const [images, setImages] = useState('');
    const imagePrefix = "https://firebasestorage.googleapis.com/v0/b/bof-app-fc36e.appspot.com/o/";
    async function uploadImages(prefix) {
        let imgIndex = 0;
        const imageUrls = {};
        for (const image of images) {
            const storageRef = sRef(storage, `${prefix}/image_${imgIndex}`);

            await uploadBytes(storageRef, image).then((snapshot) => {
                console.log('Uploaded a blob or file!');
                imageUrls[`image_${imgIndex++}`] = imagePrefix + encodeURIComponent(snapshot.metadata.fullPath) + "?alt=media";
            });
        }
        return imageUrls;
    }
    
    async function uploadHouse() {
        const path = 'conferences/conf1/house2';
        const images = await uploadImages(path);
        console.log(images);
        const house = {
           images: images,
           address: "241 Pp st",
           residents: [],
           description: "",
           price_pppn: 0,
           conference: "BTC Miami",
           contact_name: "Ashley Price",
           contact_phone: "8054050152"
        }
        set(ref(db, path), house);
    }

  return (
    <div className='upload'>
        <input
            multiple
            type="file" 
            onChange={(e)=>{
                setImages(e.target.files)
            }}
        />

        <p onClick={uploadHouse}>click</p>
    </div>
  )
}

export default Upload