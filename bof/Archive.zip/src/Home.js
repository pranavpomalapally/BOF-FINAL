import React from 'react'
import './Home.css'

import Select from 'react-select';

const aquaticCreatures = [
  { label: 'Shark', value: 'Shark' },
  { label: 'Dolphin', value: 'Dolphin' },
  { label: 'Whale', value: 'Whale' },
  { label: 'Octopus', value: 'Octopus' },
  { label: 'Crab', value: 'Crab' },
  { label: 'Lobster', value: 'Lobster' },
];

function Home() {
  return (
    <div className='home'>
      <div className='text_bar'>
        <center>content (fills remaining space)</center>
      </div>

      <div className='search_bar'>
        <Select
          options={aquaticCreatures}
        />
      </div>
    </div>
  )
}

export default Home