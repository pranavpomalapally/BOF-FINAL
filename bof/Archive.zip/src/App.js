// import logo from './logo.svg';
import './App.css';
import Home from './Home';
import Header from './Header';
import Upload from './Upload';
import Form from './Form'

import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";


function App() {
  return (
    // BEM (use app insteat of APP)

      
      <BrowserRouter>
      <Header />
        <Routes>
          <Route path="/upload" element={<Upload />} />
          <Route path="/form" element={<Form />} />
          <Route path="/" element={<Home />} />
        </Routes>
      </BrowserRouter>
  );
}

export default App;
