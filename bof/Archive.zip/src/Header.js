import React from 'react'
import './Header.css'
import logo from '/Users/pranavpomalapally/BOF/bof/src/bof.png'
import { Link } from "react-router-dom";

import Select from 'react-select';

const aquaticCreatures = [
  { label: 'Shark', value: 'Shark' },
  { label: 'Dolphin', value: 'Dolphin' },
  { label: 'Whale', value: 'Whale' },
  { label: 'Octopus', value: 'Octopus' },
  { label: 'Crab', value: 'Crab' },
  { label: 'Lobster', value: 'Lobster' },
];

function Header() {
  return (
    <div className='header'>
        <img
            className="header_icon"
            src={logo}
            alt="logo"
        />
        <div className='header_center'>
          <Select
            options={aquaticCreatures}
          />
        </div>

        <div className='header_right'>
          <Link to="/upload">Upload listing</Link>
          <Link to="/form">form</Link>
        </div>
    </div>
  )
}

export default Header